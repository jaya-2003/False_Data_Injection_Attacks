from django.shortcuts import render
from django.http import HttpResponse

def graphView(request, name):
    return HttpResponse(open("C:/Users/shyam/Downloads/project_School//"+name+".txt", 'r'))

def index(request):
    return render(request, 'index.html')

# Create your views here.
